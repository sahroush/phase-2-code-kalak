package main.visitor;

import main.ast.nodes.declaration.RecordNode;
import main.ast.nodes.declaration.ActorDec;
import main.ast.nodes.declaration.VarDeclaration;
import main.ast.nodes.declaration.Handler;
import main.ast.nodes.expression.Identifier;
import main.ast.nodes.statements.*;
import main.symbolTable.SymbolTable;
import main.symbolTable.exceptions.ItemAlreadyExists;
import main.symbolTable.exceptions.ItemNotFound;
import main.symbolTable.items.SymbolTableItem;
import main.symbolTable.items.ActorItem;
import main.symbolTable.items.VariableItem;
import main.visitor.Visitor;

import java.util.ArrayList;
import java.util.List;

public class NameAnalyzer extends Visitor<Void> {
    private List<String> errors;

    public NameAnalyzer() {
        errors = new ArrayList<>();
    }

    public List<String> getErrors() {
        return errors;
    }

    @Override
    public Void visit(RecordNode recordNode) {
        SymbolTable.push(new SymbolTable());
        for (VarDeclaration var : recordNode.getFields()) {
            visit(var);
        }
        SymbolTable.pop();
        return null;
    }

    @Override
    public Void visit(ActorDec actorDec) {
        try {
            SymbolTable.top.put(new ActorItem(actorDec));
        } catch (ItemAlreadyExists e) {
            errors.add("Line: " + actorDec.getLine() + " -> Redefinition of actor " + actorDec.getName());
        }

        SymbolTable.push(new SymbolTable());
        for (VarDeclaration var : actorDec.getActorVars()) {
            visit(var);
        }
        for (Handler handler : actorDec.getMsgHandlers()) {
            visit(handler);
        }
        SymbolTable.pop();
        return null;
    }

    @Override
    public Void visit(VarDeclaration varDeclaration) {
        try {
            SymbolTable.top.put(new VariableItem(varDeclaration));
        } catch (ItemAlreadyExists e) {
            errors.add("Line: " + varDeclaration.getLine() + " -> Redefinition of variable " + varDeclaration.getName());
        }
        return null;
    }

    @Override
    public Void visit(Handler handler) {
        try {
            SymbolTable.top.put(new SymbolTableItem(handler.getName()));
        } catch (ItemAlreadyExists e) {
            errors.add("Line: " + handler.getLine() + " -> Redefinition of Message Handler " + handler.getName());
        }
        SymbolTable.push(new SymbolTable());
        for (VarDeclaration var : handler.getArgs()) {
            visit(var);
        }
        SymbolTable.pop();
        return null;
    }

    @Override
    public Void visit(Identifier identifier) {
        try {
            SymbolTable.top.getItem(identifier.getName());
        } catch (ItemNotFound e) {
            errors.add("Line: " + identifier.getLine() + " -> Variable not declared: " + identifier.getName());
        }
        return null;
    }

    @Override
    public Void visit(AssignmentStatement assignment) {
        visit(assignment.getLValue());
        visit(assignment.getRValue());
        return null;
    }

    @Override
    public Void visit(IfStatement ifStatement) {
        visit(ifStatement.getCondition());
        visit(ifStatement.getThenBody());
        if (ifStatement.getElseBody() != null) {
            visit(ifStatement.getElseBody());
        }
        return null;
    }

    @Override
    public Void visit(WhileStatement whileStatement) {
        visit(whileStatement.getCondition());
        visit(whileStatement.getBody());
        return null;
    }

    @Override
    public Void visit(ForStatement forStatement) {
        visit(forStatement.getInit());
        visit(forStatement.getCondition());
        visit(forStatement.getUpdate());
        visit(forStatement.getBody());
        return null;
    }

    @Override
    public Void visit(ExpressionStatement expressionStatement) {
        visit(expressionStatement.getExpression());
        return null;
    }
}
